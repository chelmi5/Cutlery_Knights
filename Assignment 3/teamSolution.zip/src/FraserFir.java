public class FraserFir extends Tree
{
    public FraserFir()
    {
        this.description = "Fraser Fir";
    }

    public double cost()
    {
        return 12.0;
    }
}
