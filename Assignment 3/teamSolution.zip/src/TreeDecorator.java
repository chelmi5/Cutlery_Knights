public abstract class TreeDecorator extends Tree
{
    public abstract String getDescription();
}
