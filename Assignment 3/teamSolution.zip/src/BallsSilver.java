public class BallsSilver extends TreeDecorator
{
    private Tree tree;

    public BallsSilver(Tree t)
    {
        this.tree = t;
    }

    public String getDescription()
    {
        return tree.getDescription() + ", Silver Balls";
    }

    public double cost()
    {
        return 3.0 + tree.cost();
    }
}
