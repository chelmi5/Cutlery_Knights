public abstract class Tree
{
    String description = "Unknown Tree";

    public String getDescription()
    {
        return description;
    }

    public abstract double cost();
}
