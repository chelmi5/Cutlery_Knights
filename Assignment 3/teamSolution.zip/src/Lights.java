public class Lights extends TreeDecorator
{
    private Tree tree;

    public Lights(Tree t)
    {
        this.tree = t;
    }

    public String getDescription()
    {
        return tree.getDescription() + ", Lights";
    }

    public double cost()
    {
        return 5.0 + tree.cost();
    }
}
