public class BallsRed extends TreeDecorator
{
    private Tree tree;

    public BallsRed(Tree t)
    {
        this.tree = t;
    }

    public String getDescription()
    {
        return tree.getDescription() + ", Red Balls";
    }

    public double cost()
    {
        return 1.0 + tree.cost();
    }
}
