public class Ribbons extends TreeDecorator
{
    private Tree tree;

    public Ribbons(Tree t)
    {
        this.tree = t;
    }

    public String getDescription()
    {
        return tree.getDescription() + ", Ribbons";
    }

    public double cost()
    {
        return 2.0 + tree.cost();
    }
}
