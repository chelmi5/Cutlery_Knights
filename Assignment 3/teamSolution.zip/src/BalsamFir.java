public class BalsamFir extends Tree
{
    public BalsamFir()
    {
        this.description = "Balsam Fir";
    }

    public double cost()
    {
        return 5.0;
    }
}
