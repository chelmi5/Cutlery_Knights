public class Buffer extends TreeDecorator
{
    private Tree tree;

    public Buffer(Tree t)
    {
        this.tree = t;
    }

    public String getDescription()
    {
        return tree.getDescription() + "";
    }

    public double cost()
    {
        return 0.0 + tree.cost();
    }
}