public class DouglasFir extends Tree
{
    public DouglasFir()
    {
        this.description = "Douglas Fir";
    }

    public double cost()
    {
        return 15.0;
    }
}
