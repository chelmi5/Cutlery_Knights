/**
 * Created by Chelsea on 4/17/2015.
 */
public class BalsamFir extends Tree
{
    public BalsamFir()
    {
        this.description = "Balsam Fir";
    }

    public double cost()
    {
        return 5.0;
    }
}
