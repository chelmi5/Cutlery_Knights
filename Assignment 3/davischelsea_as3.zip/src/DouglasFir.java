/**
 * Created by Chelsea on 4/17/2015.
 */
public class DouglasFir extends Tree
{
    public DouglasFir()
    {
        this.description = "Douglas Fir";
    }

    public double cost()
    {
        return 15.0;
    }
}
