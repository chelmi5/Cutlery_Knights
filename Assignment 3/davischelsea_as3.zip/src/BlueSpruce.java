/**
 * Created by Chelsea on 4/17/2015.
 */
public class BlueSpruce extends Tree
{
    public BlueSpruce()
    {
        this.description = "Blue Spruce";
    }

    public double cost()
    {
        return 20.0;
    }
}
