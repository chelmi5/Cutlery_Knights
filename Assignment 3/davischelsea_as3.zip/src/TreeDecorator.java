/**
 * Chelsea Davis, CSCD 349, Assignment 3, Decorator
 */
public abstract class TreeDecorator extends Tree
{
    public abstract String getDescription();
}
