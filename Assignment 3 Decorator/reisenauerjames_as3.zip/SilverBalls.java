/**
 * Created by CountryGeek1 on 4/15/2015.
 */
public class SilverBalls {
    private Tree mTree;

    public SilverBalls(Tree myTree) {
        this.mTree = myTree;
    }
    public String getDescription() {
        return mTree.getDescription() + ",Balls Silver ";
    }
    public int cost() {
        return mTree.cost() + 3;
    }
}
