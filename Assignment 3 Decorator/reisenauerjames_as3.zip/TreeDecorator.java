/**
 * Created by CountryGeek1 on 4/15/2015.
 */
public abstract class TreeDecorator extends Tree {
    public abstract String getDescription();
    public abstract int cost();
}
