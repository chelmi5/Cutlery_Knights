/**
 * Created by CountryGeek1 on 4/15/2015.
 */
public class Balsam extends Tree {

    public Balsam() {
        this.setDescription("Balsam Fir");
    }

    @Override
    public int cost() {
        return 5;
    }
}
