/**
 * Created by CountryGeek1 on 4/15/2015.
 */
public abstract class Tree {
    private String description = "Unknown Tee ";

    public String getDescription(){
        return description;
    }
    public void setDescription(String str) {
        description = str + " tree decorated with";
    }
    public abstract int cost();
}
