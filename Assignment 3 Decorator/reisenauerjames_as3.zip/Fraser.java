/**
 * Created by CountryGeek1 on 4/15/2015.
 */
public class Fraser extends Tree {
   public Fraser() {
       this.setDescription("Fraser");
   }

    @Override
    public int cost() {
        return 12;
    }
}
