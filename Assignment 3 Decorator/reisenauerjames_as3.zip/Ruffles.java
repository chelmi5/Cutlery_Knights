/**
 * Created by CountryGeek1 on 4/15/2015.
 */
public class Ruffles extends TreeDecorator {
    private Tree mTree;

    public Ruffles(Tree myTree) {
        this.mTree = myTree;
    }
    @Override
    public String getDescription() {
        return mTree.getDescription() + ", Ruffles";
    }
    @Override
    public int cost() {
        return mTree.cost() + 1;
    }
}
