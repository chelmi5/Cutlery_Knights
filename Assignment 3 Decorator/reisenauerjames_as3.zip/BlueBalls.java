/**
 * Created by CountryGeek1 on 4/15/2015.
 */
public class BlueBalls {
    private Tree mTree;

    public BlueBalls(Tree myTree) {
        this.mTree = myTree;
    }
    public String getDescription() {
        return mTree.getDescription() + ", Balls Blue";
    }
    public int cost() {
        return mTree.cost() + 2;
    }
}
