/**
 * Created by CountryGeek1 on 4/15/2015.
 */
public class LEDs {
    private Tree mTree;

    public LEDs(Tree myTree) {
        this.mTree = myTree;
    }
    public String getDescription() {
        return mTree.getDescription() + ", LEDs";
    }
    public int cost() {
        return mTree.cost() + 10;
    }
}
