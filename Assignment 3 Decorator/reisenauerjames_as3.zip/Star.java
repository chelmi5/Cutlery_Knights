/**
 * Created by CountryGeek1 on 4/15/2015.
 */
public class Star extends TreeDecorator {
    private Tree mTree;
    private static Star uniqueInstance;

    private Star(Tree mytree) {
        this.mTree = mytree;
    }
    public static Star getUniqueInstance(Tree myTree) {
        if(uniqueInstance == null){
            uniqueInstance = new Star(myTree);
        }
        return uniqueInstance;
    }
    public String getDescription() {
            return mTree.getDescription() + ", a Star";
    }
    public int cost() {
            return mTree.cost() + 4;
    }
}
