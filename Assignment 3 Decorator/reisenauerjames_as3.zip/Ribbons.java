/**
 * Created by CountryGeek1 on 4/15/2015.
 */
public class Ribbons {
    private Tree mTree;

    public Ribbons(Tree myTree) {
        this.mTree = myTree;
    }
    public String getDescription() {
        return mTree.getDescription() + ", Ribbons";
    }
    public int cost() {
        return mTree.cost() + 2;
    }
}
