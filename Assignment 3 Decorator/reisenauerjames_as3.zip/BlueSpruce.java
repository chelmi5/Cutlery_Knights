/**
 * Created by CountryGeek1 on 4/15/2015.
 */
public class BlueSpruce extends Tree {
    public BlueSpruce() {
        this.setDescription("Colorado Blue Spruce");
    }

    @Override
    public int cost() {
        return 20;
    }
}
