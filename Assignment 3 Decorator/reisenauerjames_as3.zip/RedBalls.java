/**
 * Created by CountryGeek1 on 4/15/2015.
 */
public class RedBalls {
    private Tree mTree;

    public RedBalls(Tree myTree) {
        this.mTree = myTree;
    }
    public String getDescription() {
        return mTree.getDescription() + ", Balls Red";
    }
    public int cost() {
        return mTree.cost() + 1;
    }
}
