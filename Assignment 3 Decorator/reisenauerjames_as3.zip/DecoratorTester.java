/**
 * Created by CountryGeek1 on 4/15/2015.
 */
public class DecoratorTester {
    public static void main(String[] args) {
        Tree mytree = new BlueSpruce();
        mytree = Star.getUniqueInstance(mytree);
        mytree = new Ruffles(mytree);
        mytree = Star.getUniqueInstance(mytree); //this is problematic!
        mytree = new Ruffles(mytree);
        printtree(mytree);
    }

    private static void printtree(Tree mytree) {
        System.out.println(mytree.getDescription() +" cost $"+mytree.cost());
    }
}
