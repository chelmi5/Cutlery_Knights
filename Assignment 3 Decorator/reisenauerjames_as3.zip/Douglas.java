/**
 * Created by CountryGeek1 on 4/15/2015.
 */
public class Douglas extends Tree {

    public Douglas() {
        this.setDescription("Douglas Fir");
    }

    @Override
    public int cost() {
        return 15;
    }
}
