// Stormi Sprague

public class IteratorTester
{
   public static void main(String[] args)
   {
      Student a = new Student(5637,"Its","Late");
      Student b = new Student(8785,"So","Tired");
      Student c = new Student(7852,"Almost","Done");
      Student[] array = new Student[3];
      
      array[0] = a;
      array[1] = b;
      array[2] = c;
      
      Course myCourse = new Course(array);
      
      for( Student x : myCourse.students )
      {
         System.out.println(x.getFname() +" "+ x.getLname());
      }
   }//main   

}//IteratorTester