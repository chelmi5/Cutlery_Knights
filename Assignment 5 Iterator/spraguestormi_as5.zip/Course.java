// Stormi Sprague

import java.util.Iterator;
import java.util.NoSuchElementException;

public class Course implements Iterable
{
   public Student[] students;
   
   public Course(Student[] array){
      students = array;
   }
   
   public CourseIterator iterator(){
      return new CourseIterator(students);
   }
   
   
   public class CourseIterator implements Iterator{
      private int cur;
      private Student[] aggregate;
      
      public CourseIterator(Student[] array){
         this.aggregate = array;
         this.cur = 0;
      }
   
      public boolean hasNext(){
         return this.cur < this.aggregate.length;
      }
      
      public Student next(){
         if(hasNext()){
            Student item = this.aggregate[this.cur];
            this.cur++;
            return item;
         }
         throw new NoSuchElementException();         
      }
   

   }//CourseIterator class
   
   
}