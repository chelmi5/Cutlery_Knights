// Stormi Sprague

public class Student
{
   private int id;
   private String fname;
   private String lname;
   
   public Student(int id, String fname, String lname){
      this.id = id;
      this.fname = fname;
      this.lname = lname; 
   }
   
   public void setId(int id){
      this.id = id;
   }  

   public void setFname(String fname){
      this.fname = fname;
   }  

   public void setLname(String Lname){
      this.lname = Lname;
   }  
   
   public int getId(){
      return id;
   }

   public String getFname(){
      return fname;
   }
   
   public String getLname(){
      return lname;
   }

}