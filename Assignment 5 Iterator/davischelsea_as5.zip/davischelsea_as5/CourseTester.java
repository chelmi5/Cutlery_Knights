public class CourseTester
{
	public static void main(String[] args) {
		Course course = new Course();
		
		//nothing added to the list, so this proves that error checking is correct
		for(Student s : course)
		{
			System.out.println(s);
		}
		
		course.addStudent(new Student("Alice"));
		course.addStudent(new Student("Bob"));
		course.addStudent(new Student("Carl"));
		course.addStudent(new Student("Dan"));

		
		for(Student s : course)
		{
			System.out.println(s);
		}
	}

}